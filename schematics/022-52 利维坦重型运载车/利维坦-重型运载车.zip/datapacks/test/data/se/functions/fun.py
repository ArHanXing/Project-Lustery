# command = "particle minecraft:end_rod ^ ^5 ^ 0 0 0 0 1 force"
import math


def circular(count, r, displacement):
    e = 0
    while e * 0.2 < displacement:
        r += e * 0.2
        i = 0
        command = ""
        file = open(f"{e}.mcfunction", "w")

        while i <= count:
            radian = 360 / count * i
            theta = math.radians(radian)

            x = r * math.cos(theta)
            z = r * math.sin(theta)
            command += f"particle minecraft:end_rod ^{x:.2f} ^6 ^{z:.2f} 0 0 0 0 1 force\n"
            i += 1
        file.write(command)
        e += 1

circular(100, 13, 1)